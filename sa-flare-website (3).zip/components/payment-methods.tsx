export function PaymentMethods() {
  const paymentMethods = [
    { name: "EasyPaisa", color: "bg-green-600", textColor: "text-white" },
    { name: "JazzCash", color: "bg-orange-600", textColor: "text-white" },
    { name: "SadaPay", color: "bg-purple-600", textColor: "text-white" },
    { name: "NayaPay", color: "bg-blue-600", textColor: "text-white" },
  ]

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {paymentMethods.map((method) => (
        <div
          key={method.name}
          className={`${method.color} ${method.textColor} p-4 rounded-lg text-center font-semibold`}
        >
          {method.name}
        </div>
      ))}
    </div>
  )
}
