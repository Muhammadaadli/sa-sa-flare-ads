"use client"

import { Facebook, Instagram, Linkedin, Youtube } from "lucide-react"
import { Button } from "@/components/ui/button"

export function SocialLinks() {
  return (
    <section className="py-12 px-4 bg-gray-900 text-white">
      <div className="max-w-4xl mx-auto text-center">
        <h3 className="text-2xl font-bold mb-8">Follow SA Flare</h3>
        <div className="flex justify-center space-x-6">
          <Button
            variant="outline"
            size="lg"
            className="border-white text-white hover:bg-white hover:text-gray-900 bg-transparent"
            onClick={() => window.open("https://web.facebook.com/profile.php?id=61578315544036", "_blank")}
          >
            <Facebook className="h-6 w-6 mr-2" />
            Facebook
          </Button>
          <Button
            variant="outline"
            size="lg"
            className="border-white text-white hover:bg-white hover:text-gray-900 bg-transparent"
            onClick={() => window.open("https://www.instagram.com/muham.madsaad138/?__pwa=1", "_blank")}
          >
            <Instagram className="h-6 w-6 mr-2" />
            Instagram
          </Button>
          <Button
            variant="outline"
            size="lg"
            className="border-white text-white hover:bg-white hover:text-gray-900 bg-transparent"
            onClick={() => window.open("https://www.linkedin.com/in/muhammad-saad138", "_blank")}
          >
            <Linkedin className="h-6 w-6 mr-2" />
            LinkedIn
          </Button>
          <Button
            variant="outline"
            size="lg"
            className="border-white text-white hover:bg-white hover:text-gray-900 bg-transparent"
            onClick={() => window.open("https://www.youtube.com/", "_blank")}
          >
            <Youtube className="h-6 w-6 mr-2" />
            YouTube
          </Button>
        </div>
        <div className="mt-8 text-center">
          <p className="text-gray-400 mb-2">TikTok: @muhammad.saad0748</p>
          <Button
            variant="link"
            className="text-white hover:text-gray-300"
            onClick={() => window.open("https://www.tiktok.com/@muhammad.saad0748", "_blank")}
          >
            Follow on TikTok
          </Button>
        </div>
      </div>
    </section>
  )
}
