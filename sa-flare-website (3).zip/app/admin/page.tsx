"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { getOrders, updateOrderStatus } from "@/app/actions/admin-actions"
import { useActionState } from "react"

interface Order {
  id: string
  businessName: string
  fullName: string
  email: string
  phone: string
  package: string
  status: string
  createdAt: string
  totalAmount: number
}

export default function AdminPage() {
  const [orders, setOrders] = useState<Order[]>([])
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null)
  const [statusUpdateState, statusUpdateAction, isUpdating] = useActionState(updateOrderStatus, null)

  useEffect(() => {
    loadOrders()
  }, [])

  const loadOrders = async () => {
    try {
      const ordersData = await getOrders()
      setOrders(ordersData)
    } catch (error) {
      console.error("Failed to load orders:", error)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-yellow-100 text-yellow-800"
      case "in-progress":
        return "bg-blue-100 text-blue-800"
      case "completed":
        return "bg-green-100 text-green-800"
      case "cancelled":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">SA Flare Admin Dashboard</h1>
          <p className="text-gray-600">Manage your orders and client communications</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="text-2xl font-bold text-blue-600">{orders.length}</div>
              <div className="text-gray-600">Total Orders</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="text-2xl font-bold text-yellow-600">
                {orders.filter((o) => o.status === "pending").length}
              </div>
              <div className="text-gray-600">Pending</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="text-2xl font-bold text-blue-600">
                {orders.filter((o) => o.status === "in-progress").length}
              </div>
              <div className="text-gray-600">In Progress</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="text-2xl font-bold text-green-600">
                {orders.filter((o) => o.status === "completed").length}
              </div>
              <div className="text-gray-600">Completed</div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Orders List */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Orders</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4 max-h-96 overflow-y-auto">
                {orders.map((order) => (
                  <div
                    key={order.id}
                    className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                      selectedOrder?.id === order.id
                        ? "border-blue-500 bg-blue-50"
                        : "border-gray-200 hover:border-gray-300"
                    }`}
                    onClick={() => setSelectedOrder(order)}
                  >
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="font-semibold">{order.businessName}</h3>
                      <Badge className={getStatusColor(order.status)}>{order.status}</Badge>
                    </div>
                    <p className="text-sm text-gray-600">{order.fullName}</p>
                    <p className="text-sm text-gray-600">{order.email}</p>
                    <p className="text-sm text-gray-500 mt-2">{new Date(order.createdAt).toLocaleDateString()}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Order Details */}
          <Card>
            <CardHeader>
              <CardTitle>Order Details</CardTitle>
            </CardHeader>
            <CardContent>
              {selectedOrder ? (
                <div className="space-y-6">
                  <div>
                    <h3 className="text-lg font-semibold mb-4">Client Information</h3>
                    <div className="space-y-2">
                      <p>
                        <strong>Business:</strong> {selectedOrder.businessName}
                      </p>
                      <p>
                        <strong>Name:</strong> {selectedOrder.fullName}
                      </p>
                      <p>
                        <strong>Email:</strong>
                        <a href={`mailto:${selectedOrder.email}`} className="text-blue-600 hover:underline ml-1">
                          {selectedOrder.email}
                        </a>
                      </p>
                      <p>
                        <strong>Phone:</strong>
                        <a href={`tel:${selectedOrder.phone}`} className="text-blue-600 hover:underline ml-1">
                          {selectedOrder.phone}
                        </a>
                      </p>
                      <p>
                        <strong>Package:</strong> {selectedOrder.package}
                      </p>
                      <p>
                        <strong>Amount:</strong> ${selectedOrder.totalAmount}
                      </p>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-semibold mb-4">Update Status</h3>
                    <form action={statusUpdateAction} className="space-y-4">
                      <input type="hidden" name="orderId" value={selectedOrder.id} />
                      <Select name="status" defaultValue={selectedOrder.status}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="pending">Pending</SelectItem>
                          <SelectItem value="in-progress">In Progress</SelectItem>
                          <SelectItem value="completed">Completed</SelectItem>
                          <SelectItem value="cancelled">Cancelled</SelectItem>
                        </SelectContent>
                      </Select>
                      <Button type="submit" disabled={isUpdating} className="w-full">
                        {isUpdating ? "Updating..." : "Update Status"}
                      </Button>
                    </form>
                  </div>

                  <div>
                    <h3 className="text-lg font-semibold mb-4">Quick Actions</h3>
                    <div className="space-y-2">
                      <Button
                        variant="outline"
                        className="w-full bg-transparent"
                        onClick={() => window.open(`https://wa.me/${selectedOrder.phone.replace(/\D/g, "")}`, "_blank")}
                      >
                        WhatsApp Client
                      </Button>
                      <Button
                        variant="outline"
                        className="w-full bg-transparent"
                        onClick={() => window.open(`mailto:${selectedOrder.email}`, "_blank")}
                      >
                        Email Client
                      </Button>
                    </div>
                  </div>
                </div>
              ) : (
                <p className="text-gray-500">Select an order to view details</p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
