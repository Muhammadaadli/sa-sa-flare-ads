"use server"

// Mock data for demonstration - replace with actual database
const mockOrders = [
  {
    id: "1",
    businessName: "Tech Startup Co",
    fullName: "John Doe",
    email: "john@techstartup.com",
    phone: "+1234567890",
    package: "popular",
    status: "pending",
    createdAt: "2024-01-15T10:30:00Z",
    totalAmount: 300,
  },
  {
    id: "2",
    businessName: "Fashion Boutique",
    fullName: "Sarah Smith",
    email: "sarah@fashionboutique.com",
    phone: "+1234567891",
    package: "premium",
    status: "in-progress",
    createdAt: "2024-01-14T14:20:00Z",
    totalAmount: 500,
  },
]

export async function getOrders() {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 500))
  return mockOrders
}

export async function updateOrderStatus(prevState: any, formData: FormData) {
  try {
    const orderId = formData.get("orderId") as string
    const newStatus = formData.get("status") as string

    // Find and update the order
    const orderIndex = mockOrders.findIndex((order) => order.id === orderId)
    if (orderIndex !== -1) {
      mockOrders[orderIndex].status = newStatus
    }

    // In a real application, you would update the database here
    await new Promise((resolve) => setTimeout(resolve, 500))

    return {
      success: true,
      message: "Order status updated successfully",
    }
  } catch (error) {
    return {
      success: false,
      error: "Failed to update order status",
    }
  }
}
