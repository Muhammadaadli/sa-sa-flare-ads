"use server"

export async function submitOrder(prevState: any, formData: FormData) {
  try {
    // Extract form data
    const orderData = {
      package: formData.get("package"),
      businessName: formData.get("businessName"),
      industry: formData.get("industry"),
      businessDescription: formData.get("businessDescription"),
      targetAudience: formData.get("targetAudience"),
      fullName: formData.get("fullName"),
      email: formData.get("email"),
      phone: formData.get("phone"),
      whatsapp: formData.get("whatsapp"),
      specialRequests: formData.get("specialRequests"),
      paymentMethod: formData.get("paymentMethod"),
      transactionId: formData.get("transactionId"),
      addons: formData.getAll("addons"),
      createdAt: new Date().toISOString(),
      status: "pending",
    }

    // Calculate total amount based on package
    const packagePrices = {
      basic: 150,
      popular: 300,
      premium: 500,
      custom: 0,
    }

    const basePrice = packagePrices[orderData.package as keyof typeof packagePrices] || 0
    let totalAmount = basePrice

    // Add addon costs
    if (orderData.addons.includes("rush")) {
      totalAmount += basePrice * 0.2 // 20% rush fee
    }
    if (orderData.addons.includes("targeting")) {
      totalAmount += 50
    }
    if (orderData.addons.includes("testing")) {
      totalAmount += 30
    }

    // Create email content
    const emailContent = `
New Order Received - SA Flare

Order Details:
- Package: ${orderData.package}
- Business Name: ${orderData.businessName}
- Industry: ${orderData.industry}
- Total Amount: $${totalAmount}

Client Information:
- Name: ${orderData.fullName}
- Email: ${orderData.email}
- Phone: ${orderData.phone}
- WhatsApp: ${orderData.whatsapp || "Not provided"}

Business Description:
${orderData.businessDescription}

Target Audience:
${orderData.targetAudience || "Not specified"}

Special Requests:
${orderData.specialRequests || "None"}

Payment Information:
- Method: ${orderData.paymentMethod}
- Transaction ID: ${orderData.transactionId || "Pending"}

Add-ons: ${orderData.addons.length > 0 ? orderData.addons.join(", ") : "None"}

Order Date: ${new Date().toLocaleString()}
    `

    // In a real application, you would:
    // 1. Save to database
    // 2. Send email notification
    // 3. Send WhatsApp notification

    // For now, we'll simulate the process
    console.log("Order submitted:", orderData)
    console.log("Email content:", emailContent)

    // Simulate email sending (replace with actual email service)
    await new Promise((resolve) => setTimeout(resolve, 1000))

    return {
      success: true,
      message: "Order submitted successfully! We'll contact you within 10 minutes.",
    }
  } catch (error) {
    console.error("Order submission error:", error)
    return {
      success: false,
      error: "Failed to submit order. Please try again or contact us directly.",
    }
  }
}
