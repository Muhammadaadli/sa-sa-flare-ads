import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { Navbar } from "@/components/navbar"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "SA Flare - Professional Ad Creation Services | 6X Sales Growth",
  description:
    "Get high-converting ads that drive 6X sales growth. Professional ad creation for Facebook, Instagram, TikTok & more. Founded by M. Saad Ali. 50,000+ satisfied clients worldwide.",
  keywords:
    "ad creation, social media ads, Facebook ads, Instagram ads, TikTok ads, digital marketing, SA Flare, Saad Ali",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <Navbar />
        <main>{children}</main>
      </body>
    </html>
  )
}
