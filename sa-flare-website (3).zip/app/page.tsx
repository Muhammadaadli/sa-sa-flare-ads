import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Star, Users, Award, TrendingUp, ArrowRight } from "lucide-react"
import Link from "next/link"
import { SocialLinks } from "@/components/social-links"
import { PaymentMethods } from "@/components/payment-methods"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white">
      {/* Hero Section */}
      <section className="relative py-20 px-4 text-center">
        <div className="max-w-6xl mx-auto">
          <Badge className="mb-6 bg-blue-600 text-white px-6 py-2 text-lg">🏆 Award-Winning Ad Agency</Badge>
          <h1 className="text-5xl md:text-7xl font-bold text-gray-900 mb-6">
            SA <span className="text-blue-600">Flare</span>
          </h1>
          <p className="text-xl md:text-2xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Elevate Your Brand with Powerful Ads That Drive 6X Sales Growth
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Link href="/order">
              <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 text-lg">
                Order Now <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            <Link href="/services">
              <Button
                variant="outline"
                size="lg"
                className="border-blue-600 text-blue-600 hover:bg-blue-50 px-8 py-4 text-lg bg-transparent"
              >
                View Services
              </Button>
            </Link>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 max-w-4xl mx-auto">
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600 mb-2">50,000+</div>
              <div className="text-gray-600">Happy Clients</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600 mb-2">6X</div>
              <div className="text-gray-600">Sales Growth</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600 mb-2">10</div>
              <div className="text-gray-600">Industry Awards</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600 mb-2">48hrs</div>
              <div className="text-gray-600">Rush Delivery</div>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose SA Flare */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-gray-900 mb-16">Why Choose SA Flare?</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <Card className="text-center p-6 border-2 hover:border-blue-600 transition-colors">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <TrendingUp className="h-8 w-8 text-blue-600" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Affordable Prices</h3>
                <p className="text-gray-600">Premium ads without the premium price tag</p>
              </CardContent>
            </Card>

            <Card className="text-center p-6 border-2 hover:border-blue-600 transition-colors">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="h-8 w-8 text-blue-600" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Creative & Fast Team</h3>
                <p className="text-gray-600">Eye-catching designs delivered at lightning speed</p>
              </CardContent>
            </Card>

            <Card className="text-center p-6 border-2 hover:border-blue-600 transition-colors">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Star className="h-8 w-8 text-blue-600" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Proven Results</h3>
                <p className="text-gray-600">50,000+ clients globally with 6X sales increase</p>
              </CardContent>
            </Card>

            <Card className="text-center p-6 border-2 hover:border-blue-600 transition-colors">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Award className="h-8 w-8 text-blue-600" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Award-Winning</h3>
                <p className="text-gray-600">10 industry awards for outstanding performance</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 px-4 bg-blue-50">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-gray-900 mb-16">
            Get High-Converting Ads in 3 Simple Steps
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-20 h-20 bg-blue-600 text-white rounded-full flex items-center justify-center mx-auto mb-6 text-2xl font-bold">
                1
              </div>
              <h3 className="text-2xl font-semibold mb-4">Tell us about your brand</h3>
              <p className="text-gray-600">Share your goals and vision in just 5 minutes</p>
            </div>
            <div className="text-center">
              <div className="w-20 h-20 bg-blue-600 text-white rounded-full flex items-center justify-center mx-auto mb-6 text-2xl font-bold">
                2
              </div>
              <h3 className="text-2xl font-semibold mb-4">We create scroll-stopping ads</h3>
              <p className="text-gray-600">Get 3 concepts in 72 hours with unlimited revisions</p>
            </div>
            <div className="text-center">
              <div className="w-20 h-20 bg-blue-600 text-white rounded-full flex items-center justify-center mx-auto mb-6 text-2xl font-bold">
                3
              </div>
              <h3 className="text-2xl font-semibold mb-4">Your sales grow 6X faster</h3>
              <p className="text-gray-600">Watch your revenue skyrocket with our proven strategies</p>
            </div>
          </div>
        </div>
      </section>

      {/* Payment Methods */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-8">Easy Payment Options</h2>
          <p className="text-xl text-gray-600 mb-12">Pay securely through your preferred Pakistani payment method</p>
          <PaymentMethods />
          <div className="mt-8 p-6 bg-blue-50 rounded-lg">
            <p className="text-lg font-semibold text-blue-800 mb-2">Payment Number: +92 304 444 4138</p>
            <p className="text-gray-600">50% upfront, 50% after delivery • 100% Money-Back Guarantee</p>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-gradient-to-r from-blue-600 to-blue-800 text-white">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold mb-6">Ready to 6X Your Sales?</h2>
          <p className="text-xl mb-8 opacity-90">
            Join 50,000+ satisfied clients who trust SA Flare with their ad campaigns
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/order">
              <Button size="lg" className="bg-white text-blue-600 hover:bg-gray-100 px-8 py-4 text-lg">
                Start Your Order Now
              </Button>
            </Link>
            <Link href="/contact">
              <Button
                variant="outline"
                size="lg"
                className="border-white text-white hover:bg-white hover:text-blue-600 px-8 py-4 text-lg bg-transparent"
              >
                Get Free Consultation
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Social Links */}
      <SocialLinks />
    </div>
  )
}
