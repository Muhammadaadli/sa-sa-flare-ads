import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, Star, Zap, Target, TrendingUp } from "lucide-react"
import Link from "next/link"

export default function ServicesPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white">
      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <Badge className="mb-6 bg-blue-600 text-white px-6 py-2 text-lg">SA Flare Ad Services</Badge>
          <h1 className="text-5xl font-bold text-gray-900 mb-6">
            Unlimited Ad Designs | 6X Sales Guarantee | Pay Only 50% Upfront
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            🎯 Our Unlimited Ad Design Packages (Pay only for what you need!)
          </p>
        </div>
      </section>

      {/* Main Services */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12">
            {/* Social Media Ad Suite */}
            <Card className="p-8 border-2 border-blue-200 hover:border-blue-600 transition-colors">
              <CardHeader className="pb-6">
                <div className="flex items-center justify-between mb-4">
                  <CardTitle className="text-3xl font-bold text-gray-900">Social Media Ad Suite</CardTitle>
                  <Badge className="bg-blue-600 text-white px-3 py-1">Popular</Badge>
                </div>
                <p className="text-gray-600 text-lg">All-in-one ad creation for maximum impact</p>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 mb-8">
                  <div className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-green-600 mr-3" />
                    <span>All-in-one ad creation (Static, Video, Carousel)</span>
                  </div>
                  <div className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-green-600 mr-3" />
                    <span>Platforms: Facebook, Instagram, TikTok, LinkedIn</span>
                  </div>
                  <div className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-green-600 mr-3" />
                    <span>Unlimited revisions until you're satisfied</span>
                  </div>
                </div>
                <div className="bg-blue-50 p-6 rounded-lg mb-6">
                  <p className="text-2xl font-bold text-blue-600 mb-2">Starting at $50/ad</p>
                  <p className="text-gray-600">(Minimum 3 ads)</p>
                </div>
                <Link href="/order">
                  <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 text-lg">Order Now</Button>
                </Link>
              </CardContent>
            </Card>

            {/* Performance-Boosting Extras */}
            <Card className="p-8 border-2 border-yellow-200 hover:border-yellow-600 transition-colors">
              <CardHeader className="pb-6">
                <div className="flex items-center justify-between mb-4">
                  <CardTitle className="text-3xl font-bold text-gray-900">Performance-Boosting Extras</CardTitle>
                  <Badge className="bg-yellow-600 text-white px-3 py-1">Premium</Badge>
                </div>
                <p className="text-gray-600 text-lg">Advanced optimization for maximum ROI</p>
              </CardHeader>
              <CardContent>
                <div className="space-y-4 mb-8">
                  <div className="flex items-center">
                    <Zap className="h-5 w-5 text-yellow-600 mr-3" />
                    <span>+6X Sales Guarantee: Optimized for conversions</span>
                  </div>
                  <div className="flex items-center">
                    <Star className="h-5 w-5 text-yellow-600 mr-3" />
                    <span>Rush Delivery: 48-hour turnaround (+20% fee)</span>
                  </div>
                  <div className="flex items-center">
                    <Target className="h-5 w-5 text-yellow-600 mr-3" />
                    <span>Audience Targeting: We handle A/B testing</span>
                  </div>
                </div>
                <div className="bg-yellow-50 p-6 rounded-lg mb-6">
                  <p className="text-lg font-semibold text-yellow-800 mb-2">Add-on Service</p>
                  <p className="text-gray-600">Enhance any package with premium features</p>
                </div>
                <Link href="/order">
                  <Button className="w-full bg-yellow-600 hover:bg-yellow-700 text-white py-3 text-lg">
                    Add to Order
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-gray-900 mb-16">💰 Transparent Pricing</h2>
          <div className="text-center mb-12">
            <p className="text-xl text-gray-600 mb-4">(Mid-tier budgets, flexible payments)</p>
            <div className="flex flex-col sm:flex-row justify-center items-center gap-4 text-lg">
              <span className="bg-green-100 text-green-800 px-4 py-2 rounded-full font-semibold">
                50% upfront, 50% after final delivery
              </span>
              <span className="bg-blue-100 text-blue-800 px-4 py-2 rounded-full font-semibold">
                Discounts: 15% off for 10+ ad bundles
              </span>
            </div>
          </div>

          {/* Popular Package Example */}
          <Card className="p-8 border-2 border-green-200 bg-green-50">
            <CardContent>
              <div className="text-center">
                <h3 className="text-2xl font-bold text-gray-900 mb-4">Popular Package Example:</h3>
                <div className="text-4xl font-bold text-green-600 mb-2">5 Social Media Ads + 1 Video Ad = $300</div>
                <p className="text-xl text-gray-600 mb-6">(50% = $150 to start)</p>
                <Link href="/order">
                  <Button size="lg" className="bg-green-600 hover:bg-green-700 text-white px-8 py-4 text-lg">
                    Order This Package
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 px-4 bg-blue-50">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-gray-900 mb-16">🚀 How It Works</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="p-6 text-center bg-white border-2 hover:border-blue-600 transition-colors">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-blue-600 text-white rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                  1
                </div>
                <h3 className="text-xl font-semibold mb-4">Brief Us</h3>
                <p className="text-gray-600">Share your brand goals in 5 mins</p>
              </CardContent>
            </Card>

            <Card className="p-6 text-center bg-white border-2 hover:border-blue-600 transition-colors">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-blue-600 text-white rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                  2
                </div>
                <h3 className="text-xl font-semibold mb-4">Draft</h3>
                <p className="text-gray-600">Get 3 concepts in 72 hours</p>
              </CardContent>
            </Card>

            <Card className="p-6 text-center bg-white border-2 hover:border-blue-600 transition-colors">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-blue-600 text-white rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                  3
                </div>
                <h3 className="text-xl font-semibold mb-4">Finalize</h3>
                <p className="text-gray-600">We polish & launch your ads</p>
              </CardContent>
            </Card>
          </div>

          <div className="text-center mt-12">
            <Badge className="bg-blue-600 text-white px-6 py-3 text-lg">
              📌 "From brief to boost in under 1 week!"
            </Badge>
          </div>
        </div>
      </section>

      {/* Why Clients Choose Us */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-gray-900 mb-16">🌟 Why Clients Choose Us</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <Card className="p-6 text-center border-2 hover:border-blue-600 transition-colors">
              <CardContent className="pt-6">
                <TrendingUp className="h-12 w-12 text-blue-600 mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">6X ROI</h3>
                <p className="text-gray-600 text-sm">Proven track record (50,000+ ads)</p>
              </CardContent>
            </Card>

            <Card className="p-6 text-center border-2 hover:border-blue-600 transition-colors">
              <CardContent className="pt-6">
                <Star className="h-12 w-12 text-blue-600 mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">Award-Winning Team</h3>
                <p className="text-gray-600 text-sm">M. Saad Ali & Hassan Rashid</p>
              </CardContent>
            </Card>

            <Card className="p-6 text-center border-2 hover:border-blue-600 transition-colors">
              <CardContent className="pt-6">
                <CheckCircle className="h-12 w-12 text-blue-600 mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">No-Risk Payment</h3>
                <p className="text-gray-600 text-sm">Only 50% down, pay rest after results</p>
              </CardContent>
            </Card>

            <Card className="p-6 text-center border-2 hover:border-blue-600 transition-colors">
              <CardContent className="pt-6">
                <Zap className="h-12 w-12 text-blue-600 mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">100% Guarantee</h3>
                <p className="text-gray-600 text-sm">Money-back if not satisfied</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-4 bg-gradient-to-r from-blue-600 to-blue-800 text-white">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold mb-6">Ready to Start Your Ad Campaign?</h2>
          <p className="text-xl mb-8 opacity-90">Join thousands of satisfied clients and boost your sales today!</p>
          <Link href="/order">
            <Button size="lg" className="bg-yellow-500 hover:bg-yellow-600 text-black font-bold px-12 py-4 text-xl">
              Order Now - Gold Package
            </Button>
          </Link>
        </div>
      </section>
    </div>
  )
}
