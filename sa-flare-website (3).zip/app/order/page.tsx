"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Badge } from "@/components/ui/badge"
import { PaymentMethods } from "@/components/payment-methods"
import { submitOrder } from "@/app/actions/submit-order"
import { useActionState } from "react"

export default function OrderPage() {
  const [state, action, isPending] = useActionState(submitOrder, null)
  const [selectedPackage, setSelectedPackage] = useState("")
  const [totalPrice, setTotalPrice] = useState(0)

  const packages = [
    { id: "basic", name: "Basic Package", price: 150, ads: 3, description: "3 Social Media Ads" },
    { id: "popular", name: "Popular Package", price: 300, ads: 6, description: "5 Social Media Ads + 1 Video Ad" },
    { id: "premium", name: "Premium Package", price: 500, ads: 10, description: "8 Social Media Ads + 2 Video Ads" },
    { id: "custom", name: "Custom Package", price: 0, ads: 0, description: "Tell us your requirements" },
  ]

  const handlePackageChange = (packageId: string) => {
    setSelectedPackage(packageId)
    const pkg = packages.find((p) => p.id === packageId)
    setTotalPrice(pkg ? pkg.price : 0)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white">
      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <Badge className="mb-6 bg-blue-600 text-white px-6 py-2 text-lg">Order Your Ads Now</Badge>
          <h1 className="text-5xl font-bold text-gray-900 mb-6">Get High-Converting Ads That Drive 6X Sales</h1>
          <p className="text-xl text-gray-600 mb-8">Choose your package and let's boost your business today!</p>
        </div>
      </section>

      {/* Order Form */}
      <section className="py-20 px-4">
        <div className="max-w-4xl mx-auto">
          <form action={action} className="space-y-8">
            {/* Package Selection */}
            <Card className="p-8">
              <CardHeader>
                <CardTitle className="text-2xl">Choose Your Package</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-6">
                  {packages.map((pkg) => (
                    <div key={pkg.id} className="relative">
                      <input
                        type="radio"
                        id={pkg.id}
                        name="package"
                        value={pkg.id}
                        onChange={() => handlePackageChange(pkg.id)}
                        className="peer sr-only"
                        required
                      />
                      <Label
                        htmlFor={pkg.id}
                        className={`flex flex-col p-6 border-2 rounded-lg cursor-pointer transition-colors ${
                          pkg.id === "popular" ? "border-blue-600 bg-blue-50" : "border-gray-200"
                        } hover:border-blue-600 peer-checked:border-blue-600 peer-checked:bg-blue-50`}
                      >
                        {pkg.id === "popular" && (
                          <Badge className="absolute -top-2 left-4 bg-blue-600 text-white">Most Popular</Badge>
                        )}
                        <h3 className="text-xl font-semibold mb-2">{pkg.name}</h3>
                        <p className="text-gray-600 mb-4">{pkg.description}</p>
                        {pkg.price > 0 && (
                          <div className="text-2xl font-bold text-blue-600">
                            ${pkg.price} <span className="text-sm text-gray-500">({pkg.ads} ads)</span>
                          </div>
                        )}
                      </Label>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Business Information */}
            <Card className="p-8">
              <CardHeader>
                <CardTitle className="text-2xl">Business Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="businessName">Business Name *</Label>
                    <Input id="businessName" name="businessName" required />
                  </div>
                  <div>
                    <Label htmlFor="industry">Industry *</Label>
                    <Select name="industry" required>
                      <SelectTrigger>
                        <SelectValue placeholder="Select your industry" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="ecommerce">E-commerce</SelectItem>
                        <SelectItem value="fashion">Fashion</SelectItem>
                        <SelectItem value="food">Food & Restaurant</SelectItem>
                        <SelectItem value="tech">Technology</SelectItem>
                        <SelectItem value="health">Health & Fitness</SelectItem>
                        <SelectItem value="beauty">Beauty & Cosmetics</SelectItem>
                        <SelectItem value="education">Education</SelectItem>
                        <SelectItem value="real-estate">Real Estate</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <Label htmlFor="businessDescription">Tell us about your business *</Label>
                  <Textarea
                    id="businessDescription"
                    name="businessDescription"
                    placeholder="Describe your products/services, target audience, and goals..."
                    rows={4}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="targetAudience">Target Audience</Label>
                  <Input
                    id="targetAudience"
                    name="targetAudience"
                    placeholder="e.g., Women 25-35, interested in fitness"
                  />
                </div>
              </CardContent>
            </Card>

            {/* Contact Information */}
            <Card className="p-8">
              <CardHeader>
                <CardTitle className="text-2xl">Contact Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="fullName">Full Name *</Label>
                    <Input id="fullName" name="fullName" required />
                  </div>
                  <div>
                    <Label htmlFor="email">Email Address *</Label>
                    <Input id="email" name="email" type="email" required />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="phone">Phone Number *</Label>
                    <Input id="phone" name="phone" type="tel" required />
                  </div>
                  <div>
                    <Label htmlFor="whatsapp">WhatsApp Number</Label>
                    <Input id="whatsapp" name="whatsapp" type="tel" />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Additional Requirements */}
            <Card className="p-8">
              <CardHeader>
                <CardTitle className="text-2xl">Additional Requirements</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <Label htmlFor="specialRequests">Special Requests or Instructions</Label>
                  <Textarea
                    id="specialRequests"
                    name="specialRequests"
                    placeholder="Any specific requirements, brand colors, style preferences, etc."
                    rows={3}
                  />
                </div>

                <div className="space-y-4">
                  <Label>Add-on Services</Label>
                  <div className="space-y-3">
                    <div className="flex items-center space-x-2">
                      <Checkbox id="rushDelivery" name="addons" value="rush" />
                      <Label htmlFor="rushDelivery">Rush Delivery (48 hours) - +20% fee</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox id="targeting" name="addons" value="targeting" />
                      <Label htmlFor="targeting">Advanced Audience Targeting - +$50</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox id="abTesting" name="addons" value="testing" />
                      <Label htmlFor="abTesting">A/B Testing Setup - +$30</Label>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Payment Information */}
            <Card className="p-8">
              <CardHeader>
                <CardTitle className="text-2xl">Payment Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="bg-blue-50 p-6 rounded-lg">
                  <h3 className="text-lg font-semibold mb-4">Payment Details</h3>
                  {totalPrice > 0 && (
                    <div className="space-y-2 mb-4">
                      <div className="flex justify-between">
                        <span>Package Total:</span>
                        <span className="font-semibold">${totalPrice}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>50% Upfront Payment:</span>
                        <span className="font-bold text-blue-600">${totalPrice / 2}</span>
                      </div>
                      <div className="flex justify-between text-sm text-gray-600">
                        <span>Remaining 50% after delivery:</span>
                        <span>${totalPrice / 2}</span>
                      </div>
                    </div>
                  )}
                  <p className="text-sm text-gray-600 mb-4">
                    Payment Number: <strong>+92 304 444 4138</strong>
                  </p>
                </div>

                <PaymentMethods />

                <div>
                  <Label htmlFor="paymentMethod">Select Payment Method *</Label>
                  <Select name="paymentMethod" required>
                    <SelectTrigger>
                      <SelectValue placeholder="Choose payment method" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="easypaisa">EasyPaisa</SelectItem>
                      <SelectItem value="jazzcash">JazzCash</SelectItem>
                      <SelectItem value="sadapay">SadaPay</SelectItem>
                      <SelectItem value="nayapay">NayaPay</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="transactionId">Transaction ID (after payment)</Label>
                  <Input
                    id="transactionId"
                    name="transactionId"
                    placeholder="Enter transaction ID after making payment"
                  />
                </div>
              </CardContent>
            </Card>

            {/* Terms and Submit */}
            <Card className="p-8">
              <CardContent className="space-y-6">
                <div className="flex items-center space-x-2">
                  <Checkbox id="terms" name="terms" required />
                  <Label htmlFor="terms" className="text-sm">
                    I agree to the terms and conditions and understand the 50% upfront payment policy *
                  </Label>
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox id="updates" name="updates" />
                  <Label htmlFor="updates" className="text-sm">
                    I want to receive updates about my order via WhatsApp and email
                  </Label>
                </div>

                <Button
                  type="submit"
                  size="lg"
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white py-4 text-xl"
                  disabled={isPending}
                >
                  {isPending ? "Submitting Order..." : "Submit Order Now"}
                </Button>

                {state?.success && (
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                    <p className="text-green-800 font-semibold">✅ Order submitted successfully!</p>
                    <p className="text-green-700 text-sm mt-1">We'll contact you within 10 minutes via WhatsApp.</p>
                  </div>
                )}

                {state?.error && (
                  <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                    <p className="text-red-800 font-semibold">❌ Error submitting order</p>
                    <p className="text-red-700 text-sm mt-1">{state.error}</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </form>
        </div>
      </section>
    </div>
  )
}
