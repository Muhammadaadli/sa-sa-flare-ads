import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Phone, Mail, MessageCircle, Clock, CheckCircle, Zap } from "lucide-react"
import { ContactForm } from "@/components/contact-form"
import { SocialLinks } from "@/components/social-links"

export default function ContactPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white">
      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <Badge className="mb-6 bg-blue-600 text-white px-6 py-2 text-lg">Contact SA Flare</Badge>
          <h1 className="text-5xl font-bold text-gray-900 mb-6">Get High-Converting Ads in 3 Simple Steps</h1>
          <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto mb-12">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-600 text-white rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                1
              </div>
              <p className="text-lg font-semibold">Tell us about your brand</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-600 text-white rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                2
              </div>
              <p className="text-lg font-semibold">We create scroll-stopping ads</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-600 text-white rounded-full flex items-center justify-center mx-auto mb-4 text-xl font-bold">
                3
              </div>
              <p className="text-lg font-semibold">Your sales grow 6X faster</p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Methods */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-gray-900 mb-16">Fastest Ways to Reach Us</h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
            {/* WhatsApp */}
            <Card className="p-6 text-center border-2 border-green-200 hover:border-green-600 transition-colors">
              <CardContent className="pt-4">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <MessageCircle className="h-8 w-8 text-green-600" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Priority WhatsApp</h3>
                <p className="text-gray-600 mb-4">Responses within 10 minutes</p>
                <a
                  href="https://wa.me/923044444138"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-green-600 hover:underline font-semibold"
                >
                  +92 304 444 4138
                </a>
              </CardContent>
            </Card>

            {/* Email */}
            <Card className="p-6 text-center border-2 border-blue-200 hover:border-blue-600 transition-colors">
              <CardContent className="pt-4">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Mail className="h-8 w-8 text-blue-600" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Email for Briefs</h3>
                <p className="text-gray-600 mb-4">Detailed project discussions</p>
                <a href="mailto:slisaad445@gmail.com" className="text-blue-600 hover:underline font-semibold">
                  slisaad445@gmail.com
                </a>
              </CardContent>
            </Card>

            {/* Phone */}
            <Card className="p-6 text-center border-2 border-red-200 hover:border-red-600 transition-colors">
              <CardContent className="pt-4">
                <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Phone className="h-8 w-8 text-red-600" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Urgent Calls</h3>
                <p className="text-gray-600 mb-4">15 minute response</p>
                <a href="tel:+923044444138" className="text-red-600 hover:underline font-semibold">
                  +92 304 444 4138
                </a>
              </CardContent>
            </Card>

            {/* Live Chat */}
            <Card className="p-6 text-center border-2 border-purple-200 hover:border-purple-600 transition-colors">
              <CardContent className="pt-4">
                <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <MessageCircle className="h-8 w-8 text-purple-600" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Live Chat Support</h3>
                <p className="text-gray-600 mb-4">Available now</p>
                <span className="text-purple-600 font-semibold">Click icon below right</span>
              </CardContent>
            </Card>
          </div>

          {/* Team Contact */}
          <div className="grid md:grid-cols-2 gap-8 mb-16">
            <Card className="p-8 border-2 border-blue-200">
              <CardHeader>
                <CardTitle className="text-2xl text-center">M. Saad Ali - Founder</CardTitle>
              </CardHeader>
              <CardContent className="text-center space-y-4">
                <div className="w-24 h-24 bg-gradient-to-br from-blue-600 to-blue-800 rounded-full flex items-center justify-center mx-auto">
                  <span className="text-2xl font-bold text-white">SA</span>
                </div>
                <p className="text-gray-600">Personally oversees premium orders</p>
                <div className="space-y-2">
                  <p>
                    📧{" "}
                    <a href="mailto:slisaad445@gmail.com" className="text-blue-600 hover:underline">
                      slisaad445@gmail.com
                    </a>
                  </p>
                  <p>
                    📱{" "}
                    <a href="tel:+923044444138" className="text-blue-600 hover:underline">
                      +92 304 444 4138
                    </a>
                  </p>
                  <p>
                    💼{" "}
                    <a
                      href="https://www.linkedin.com/in/muhammad-saad138"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-600 hover:underline"
                    >
                      LinkedIn
                    </a>
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card className="p-8 border-2 border-green-200">
              <CardHeader>
                <CardTitle className="text-2xl text-center">Hassan Rashid - Lead Strategist</CardTitle>
              </CardHeader>
              <CardContent className="text-center space-y-4">
                <div className="w-24 h-24 bg-gradient-to-br from-green-600 to-green-800 rounded-full flex items-center justify-center mx-auto">
                  <span className="text-2xl font-bold text-white">HR</span>
                </div>
                <p className="text-gray-600">Social media ads marketer</p>
                <div className="space-y-2">
                  <p>
                    📧{" "}
                    <a href="mailto:chhd300@gmail.com" className="text-blue-600 hover:underline">
                      chhd300@gmail.com
                    </a>
                  </p>
                  <p>
                    📱{" "}
                    <a href="tel:+923166630048" className="text-blue-600 hover:underline">
                      +92 316 663 0048
                    </a>
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Why Contact SA Flare */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-gray-900 mb-16">Why Contact SA Flare?</h2>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="flex items-center space-x-4">
              <CheckCircle className="h-8 w-8 text-green-600 flex-shrink-0" />
              <span className="text-lg">50,000+ satisfied global clients</span>
            </div>
            <div className="flex items-center space-x-4">
              <CheckCircle className="h-8 w-8 text-green-600 flex-shrink-0" />
              <span className="text-lg">10 award-winning ad strategies</span>
            </div>
            <div className="flex items-center space-x-4">
              <CheckCircle className="h-8 w-8 text-green-600 flex-shrink-0" />
              <span className="text-lg">Founder M. Saad Ali personally oversees premium orders</span>
            </div>
            <div className="flex items-center space-x-4">
              <CheckCircle className="h-8 w-8 text-green-600 flex-shrink-0" />
              <span className="text-lg">Student-friendly pricing</span>
            </div>
          </div>
        </div>
      </section>

      {/* Rush Orders */}
      <section className="py-20 px-4 bg-yellow-50">
        <div className="max-w-4xl mx-auto text-center">
          <div className="flex items-center justify-center mb-6">
            <Zap className="h-12 w-12 text-yellow-600 mr-4" />
            <h2 className="text-4xl font-bold text-gray-900">For Rush Orders</h2>
          </div>
          <div className="bg-yellow-200 p-8 rounded-lg mb-8">
            <p className="text-2xl font-bold text-yellow-800 mb-4">Mention "GOLD RUSH" for 48-hour delivery</p>
            <p className="text-lg text-yellow-700">Priority processing for urgent campaigns</p>
          </div>
        </div>
      </section>

      {/* Office Hours */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-gray-900 mb-16">Office Hours</h2>
          <div className="grid md:grid-cols-2 gap-8">
            <Card className="p-8 border-2 border-blue-200">
              <CardContent className="pt-4 text-center">
                <Clock className="h-16 w-16 text-blue-600 mx-auto mb-4" />
                <h3 className="text-2xl font-semibold mb-4">Weekdays</h3>
                <p className="text-xl text-gray-600">Monday-Friday: 9AM-6PM GMT</p>
                <p className="text-sm text-gray-500 mt-2">Full support available</p>
              </CardContent>
            </Card>

            <Card className="p-8 border-2 border-gray-200">
              <CardContent className="pt-4 text-center">
                <Mail className="h-16 w-16 text-gray-600 mx-auto mb-4" />
                <h3 className="text-2xl font-semibold mb-4">Weekends</h3>
                <p className="text-xl text-gray-600">Email support only</p>
                <p className="text-sm text-gray-500 mt-2">Response within 24 hours</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Contact Form */}
      <section className="py-20 px-4 bg-blue-50">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-gray-900 mb-16">Send Us a Message</h2>
          <ContactForm />
        </div>
      </section>

      {/* Social Links */}
      <SocialLinks />
    </div>
  )
}
