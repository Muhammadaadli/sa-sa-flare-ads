import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Star, TrendingUp, Clock, Target, RefreshCw } from "lucide-react"

export default function TestimonialsPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white">
      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <Badge className="mb-6 bg-blue-600 text-white px-6 py-2 text-lg">Client Success Stories</Badge>
          <h1 className="text-5xl font-bold text-gray-900 mb-6">Real Results from Real Clients</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            See how SA Flare has transformed businesses and skyrocketed sales for clients worldwide
          </p>
        </div>
      </section>

      {/* Featured Testimonial */}
      <section className="py-20 px-4">
        <div className="max-w-4xl mx-auto">
          <Card className="p-8 border-2 border-blue-200 bg-gradient-to-br from-blue-50 to-white">
            <CardContent className="pt-6">
              <div className="text-center mb-8">
                <Badge className="bg-green-600 text-white px-4 py-2 text-lg mb-4">Featured Case Study</Badge>
                <h2 className="text-3xl font-bold text-gray-900 mb-4">Sport Brand Case Study</h2>
              </div>

              <div className="bg-white p-8 rounded-lg shadow-lg mb-8">
                <div className="flex items-center mb-6">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-6 w-6 text-yellow-500 fill-current" />
                  ))}
                </div>

                <blockquote className="text-2xl font-semibold text-gray-900 mb-6 leading-relaxed">
                  "SA Flare's Ads Skyrocketed Our Daily Revenue from $20 to $100 in Just 2 Weeks!"
                </blockquote>

                <p className="text-lg text-gray-600 mb-8 leading-relaxed">
                  "As a growing sport brand, we struggled to break past $20/day in sales. SA Flare's team transformed
                  our ads with high-energy creatives and precision targeting. Within 14 days, we hit $100/day
                  consistently – a 5X boost! M. Saad Ali's strategic tweaks and Hassan Rashid's scroll-stopping designs
                  made all the difference. Now, we trust them with every product launch."
                </p>

                <div className="flex items-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-green-600 to-green-800 rounded-full flex items-center justify-center mr-4">
                    <span className="text-xl font-bold text-white">AH</span>
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">Ali Hassan</p>
                    <p className="text-gray-600">Founder, Al-Ikhsan Sports</p>
                  </div>
                </div>
              </div>

              {/* Key Results */}
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                <Card className="p-6 text-center bg-white border-2 border-green-200">
                  <CardContent className="pt-4">
                    <TrendingUp className="h-12 w-12 text-green-600 mx-auto mb-4" />
                    <h3 className="text-2xl font-bold text-green-600 mb-2">5X</h3>
                    <p className="text-gray-600 text-sm">Revenue Increase</p>
                    <p className="text-xs text-gray-500 mt-1">($20 → $100/day)</p>
                  </CardContent>
                </Card>

                <Card className="p-6 text-center bg-white border-2 border-blue-200">
                  <CardContent className="pt-4">
                    <Clock className="h-12 w-12 text-blue-600 mx-auto mb-4" />
                    <h3 className="text-2xl font-bold text-blue-600 mb-2">14</h3>
                    <p className="text-gray-600 text-sm">Days</p>
                    <p className="text-xs text-gray-500 mt-1">Rapid Turnaround</p>
                  </CardContent>
                </Card>

                <Card className="p-6 text-center bg-white border-2 border-purple-200">
                  <CardContent className="pt-4">
                    <Target className="h-12 w-12 text-purple-600 mx-auto mb-4" />
                    <h3 className="text-2xl font-bold text-purple-600 mb-2">100%</h3>
                    <p className="text-gray-600 text-sm">Data-Driven</p>
                    <p className="text-xs text-gray-500 mt-1">Meta Ads + Google</p>
                  </CardContent>
                </Card>

                <Card className="p-6 text-center bg-white border-2 border-orange-200">
                  <CardContent className="pt-4">
                    <RefreshCw className="h-12 w-12 text-orange-600 mx-auto mb-4" />
                    <h3 className="text-2xl font-bold text-orange-600 mb-2">Ongoing</h3>
                    <p className="text-gray-600 text-sm">Partnership</p>
                    <p className="text-xs text-gray-500 mt-1">New collections</p>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* More Testimonials */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-gray-900 mb-16">What Our 50,000+ Clients Say</h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="p-6 border-2 hover:border-blue-600 transition-colors">
              <CardContent className="pt-4">
                <div className="flex items-center mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-4 w-4 text-yellow-500 fill-current" />
                  ))}
                </div>
                <p className="text-gray-600 mb-4">
                  "Incredible results! Our e-commerce sales doubled within the first month of using SA Flare's ads."
                </p>
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center mr-3">
                    <span className="text-sm font-bold text-white">MK</span>
                  </div>
                  <div>
                    <p className="font-semibold text-sm">Maria Khan</p>
                    <p className="text-xs text-gray-500">Fashion Store Owner</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="p-6 border-2 hover:border-blue-600 transition-colors">
              <CardContent className="pt-4">
                <div className="flex items-center mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-4 w-4 text-yellow-500 fill-current" />
                  ))}
                </div>
                <p className="text-gray-600 mb-4">
                  "Professional service, quick delivery, and amazing results. SA Flare exceeded all expectations!"
                </p>
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-green-600 rounded-full flex items-center justify-center mr-3">
                    <span className="text-sm font-bold text-white">AR</span>
                  </div>
                  <div>
                    <p className="font-semibold text-sm">Ahmed Raza</p>
                    <p className="text-xs text-gray-500">Tech Startup</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="p-6 border-2 hover:border-blue-600 transition-colors">
              <CardContent className="pt-4">
                <div className="flex items-center mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-4 w-4 text-yellow-500 fill-current" />
                  ))}
                </div>
                <p className="text-gray-600 mb-4">
                  "The team's creativity and strategic approach helped us reach new audiences we never thought
                  possible."
                </p>
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-purple-600 rounded-full flex items-center justify-center mr-3">
                    <span className="text-sm font-bold text-white">SF</span>
                  </div>
                  <div>
                    <p className="font-semibold text-sm">Sara Fatima</p>
                    <p className="text-xs text-gray-500">Beauty Brand</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="p-6 border-2 hover:border-blue-600 transition-colors">
              <CardContent className="pt-4">
                <div className="flex items-center mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-4 w-4 text-yellow-500 fill-current" />
                  ))}
                </div>
                <p className="text-gray-600 mb-4">
                  "From concept to execution, SA Flare delivered beyond our expectations. Highly recommended!"
                </p>
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-red-600 rounded-full flex items-center justify-center mr-3">
                    <span className="text-sm font-bold text-white">UA</span>
                  </div>
                  <div>
                    <p className="font-semibold text-sm">Usman Ali</p>
                    <p className="text-xs text-gray-500">Restaurant Chain</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="p-6 border-2 hover:border-blue-600 transition-colors">
              <CardContent className="pt-4">
                <div className="flex items-center mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-4 w-4 text-yellow-500 fill-current" />
                  ))}
                </div>
                <p className="text-gray-600 mb-4">
                  "The ROI we got from SA Flare's ads was incredible. Best investment we made for our business!"
                </p>
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-indigo-600 rounded-full flex items-center justify-center mr-3">
                    <span className="text-sm font-bold text-white">ZH</span>
                  </div>
                  <div>
                    <p className="font-semibold text-sm">Zara Hassan</p>
                    <p className="text-xs text-gray-500">Online Course Creator</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="p-6 border-2 hover:border-blue-600 transition-colors">
              <CardContent className="pt-4">
                <div className="flex items-center mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-4 w-4 text-yellow-500 fill-current" />
                  ))}
                </div>
                <p className="text-gray-600 mb-4">
                  "Fast, affordable, and effective. SA Flare helped us scale our business to new heights!"
                </p>
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-teal-600 rounded-full flex items-center justify-center mr-3">
                    <span className="text-sm font-bold text-white">FK</span>
                  </div>
                  <div>
                    <p className="font-semibold text-sm">Faisal Khan</p>
                    <p className="text-xs text-gray-500">Digital Agency</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 px-4 bg-blue-50">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold text-gray-900 mb-16">Trusted by Thousands Worldwide</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div>
              <div className="text-4xl font-bold text-blue-600 mb-2">50,000+</div>
              <div className="text-gray-600">Happy Clients</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-blue-600 mb-2">6X</div>
              <div className="text-gray-600">Average ROI</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-blue-600 mb-2">10</div>
              <div className="text-gray-600">Industry Awards</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-blue-600 mb-2">99%</div>
              <div className="text-gray-600">Satisfaction Rate</div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
