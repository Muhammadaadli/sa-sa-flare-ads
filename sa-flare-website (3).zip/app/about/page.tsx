import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Users, Target, Award, Globe } from "lucide-react"

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white">
      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <Badge className="mb-6 bg-blue-600 text-white px-6 py-2 text-lg">About SA Flare</Badge>
          <h1 className="text-5xl font-bold text-gray-900 mb-6">Elevate Your Brand with Powerful Ads</h1>
          <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
            Welcome to SA Flare, where creativity meets strategy to boost your brand's reach and sales like never
            before! Founded by M. Saad Ali and powered by a talented team including Hassan Rashid, we specialize in
            high-impact social media ad creation that drives real results—affordably, quickly, and effectively.
          </p>
        </div>
      </section>

      {/* Why Choose SA Flare */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-gray-900 mb-16">Why Choose SA Flare?</h2>
          <div className="grid md:grid-cols-2 gap-8">
            <Card className="p-8 border-2 hover:border-blue-600 transition-colors">
              <CardContent className="pt-0">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mr-4">
                    <Target className="h-6 w-6 text-blue-600" />
                  </div>
                  <h3 className="text-2xl font-semibold">Affordable Prices</h3>
                </div>
                <p className="text-gray-600 text-lg">Premium ads without the premium price tag.</p>
              </CardContent>
            </Card>

            <Card className="p-8 border-2 hover:border-blue-600 transition-colors">
              <CardContent className="pt-0">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mr-4">
                    <Users className="h-6 w-6 text-blue-600" />
                  </div>
                  <h3 className="text-2xl font-semibold">Creative & Fast Team</h3>
                </div>
                <p className="text-gray-600 text-lg">Eye-catching designs delivered at lightning speed.</p>
              </CardContent>
            </Card>

            <Card className="p-8 border-2 hover:border-blue-600 transition-colors">
              <CardContent className="pt-0">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mr-4">
                    <Globe className="h-6 w-6 text-blue-600" />
                  </div>
                  <h3 className="text-2xl font-semibold">Proven Results</h3>
                </div>
                <p className="text-gray-600 text-lg">
                  We've helped 50,000+ clients globally increase their sales by up to 6X.
                </p>
              </CardContent>
            </Card>

            <Card className="p-8 border-2 hover:border-blue-600 transition-colors">
              <CardContent className="pt-0">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mr-4">
                    <Award className="h-6 w-6 text-blue-600" />
                  </div>
                  <h3 className="text-2xl font-semibold">Award-Winning Excellence</h3>
                </div>
                <p className="text-gray-600 text-lg">
                  Recognized with 10 industry awards for outstanding ad performance.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Mission */}
      <section className="py-20 px-4 bg-blue-50">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold text-gray-900 mb-8">Our Mission</h2>
          <p className="text-xl text-gray-600 leading-relaxed">
            We're on a mission to help businesses and entrepreneurs worldwide—especially students and hustlers like
            us—earn more by spending less on ads. Whether you're a startup or an established brand, our tailored ad
            strategies make your product irresistible to your audience.
          </p>
        </div>
      </section>

      {/* Meet the Team */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-gray-900 mb-16">Meet the Team</h2>
          <div className="grid md:grid-cols-2 gap-12 max-w-4xl mx-auto">
            <Card className="p-8 text-center border-2 hover:border-blue-600 transition-colors">
              <CardContent className="pt-6">
                <div className="w-32 h-32 bg-gradient-to-br from-blue-600 to-blue-800 rounded-full flex items-center justify-center mx-auto mb-6">
                  <span className="text-4xl font-bold text-white">SA</span>
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-2">M. Saad Ali</h3>
                <p className="text-blue-600 font-semibold mb-4">Founder & CEO</p>
                <p className="text-gray-600 mb-4">
                  The visionary behind SA Flare, turning ad concepts into profit. Mastermind behind campaigns that
                  convert.
                </p>
                <div className="space-y-2 text-sm text-gray-500">
                  <p>
                    📧{" "}
                    <a href="mailto:slisaad445@gmail.com" className="text-blue-600 hover:underline">
                      slisaad445@gmail.com
                    </a>
                  </p>
                  <p>
                    📱{" "}
                    <a href="tel:+923044444138" className="text-blue-600 hover:underline">
                      +92 304 444 4138
                    </a>
                  </p>
                  <p>
                    💼{" "}
                    <a
                      href="https://www.linkedin.com/in/muhammad-saad138"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-600 hover:underline"
                    >
                      LinkedIn Profile
                    </a>
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card className="p-8 text-center border-2 hover:border-blue-600 transition-colors">
              <CardContent className="pt-6">
                <div className="w-32 h-32 bg-gradient-to-br from-green-600 to-green-800 rounded-full flex items-center justify-center mx-auto mb-6">
                  <span className="text-4xl font-bold text-white">HR</span>
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-2">Hassan Rashid</h3>
                <p className="text-green-600 font-semibold mb-4">Lead Strategist</p>
                <p className="text-gray-600 mb-4">
                  Social media ads marketer specializing in scroll-stopping designs and conversion optimization.
                </p>
                <div className="space-y-2 text-sm text-gray-500">
                  <p>
                    📧{" "}
                    <a href="mailto:chhd300@gmail.com" className="text-blue-600 hover:underline">
                      chhd300@gmail.com
                    </a>
                  </p>
                  <p>
                    📱{" "}
                    <a href="tel:+923166630048" className="text-blue-600 hover:underline">
                      +92 316 663 0048
                    </a>
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="text-center mt-12">
            <p className="text-xl text-gray-600 font-medium">
              We're not just an agency; we're your growth partners. Let's make your brand shine—one ad at a time!
            </p>
          </div>
        </div>
      </section>
    </div>
  )
}
